# config.py

BOT_TOKEN = "7722719066:AAH4cRPPdkbNOggZ8ujPWrJ5tLhjvzPvJvY"
GROUP_CHAT_ID = -1002250802160  # замените на ваш реальный ID группы

# ID операторов Telegram, у которых есть доступ к управлению верификацией
OPERATORS = [8058997213]


